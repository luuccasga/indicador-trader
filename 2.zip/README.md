
# Trader Indicator - Image-based Chart Analyzer

This is a best-effort Flask web service that analyses a **chart image** (candlestick chart) and returns a buy/sell/hold recommendation with a probability and confidence score.

**Important notes (read before deploying):**
- This tool is heuristic and **does not guarantee** profitability. Use at your own risk.
- For more accurate mapping from pixels to price, charts with visible y-axis numeric labels are better (the app will try OCR to extract them).
- The code is ready to deploy on Render.com as a Python web service (Procfile included).

## Files
- `app.py` - Flask application with `/predict` endpoint.
- `requirements.txt` - Python dependencies.
- `Procfile` - For Render.com
- `README.md` - This file.

## How to use (after deploy)
1. Deploy on Render.com as a Python web service (select "Deploy with Docker" or connect GitHub repo).
2. Send a POST request (multipart/form-data) to `/predict` with key `chart` containing your image file (PNG/JPG).
   ```bash
   curl -X POST -F "chart=@chart.png" https://your-app.onrender.com/predict
   ```
3. Response example:
   ```json
   {
     "timestamp_utc": "2025-11-09T22:00:00.123Z",
     "timezone": "UTC",
     "input_candles_detected": 12,
     "analysis": {
       "recommendation": "BUY",
       "probability": 72.5,
       "confidence": 0.68,
       "notes": "Upward short-term slope; Short MA above Long MA (bullish); Recent positive momentum (0.45%)",
       "short_ma": 1.2345,
       "long_ma": 1.2300,
       "slope": 0.00012,
       "last_pct": 0.45
     }
   }
   ```

## Customize / Improve
- Integrate a proper price-extraction routine using the chart's axis or add an input field for top/bottom price to convert pixels to real prices.
- Replace heuristics with a deep learning model trained on labeled candlestick images for better accuracy.
- Add authentication and rate-limiting for production use.

## Disclaimer
This is educational/example code. It is **not financial advice**.
