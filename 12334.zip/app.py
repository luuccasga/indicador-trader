from flask import Flask, request, jsonify
import cv2
import numpy as np
from PIL import Image
import datetime

app = Flask(__name__)

@app.route('/')
def home():
    return "Indicador Trader IA rodando com sucesso! 🚀"

@app.route('/analisar', methods=['POST'])
def analisar():
    try:
        if 'imagem' not in request.files:
            return jsonify({'erro': 'Envie uma imagem chamada "imagem" no formulário.'}), 400

        imagem = request.files['imagem']
        img_bytes = imagem.read()
        np_img = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(np_img, cv2.IMREAD_COLOR)

        media_cor = np.mean(img)
        horario = datetime.datetime.now().strftime("%H:%M:%S")

        if media_cor > 127:
            direcao = "COMPRA (CALL)"
            probabilidade = 78.5
        else:
            direcao = "VENDA (PUT)"
            probabilidade = 81.3

        return jsonify({
            "direcao": direcao,
            "horario_sinal": horario,
            "probabilidade": f"{probabilidade:.2f}%",
            "mensagem": "Análise concluída com sucesso!"
        })

    except Exception as e:
        return jsonify({'erro': str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
