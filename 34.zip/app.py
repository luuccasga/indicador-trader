
import io, os, datetime, math, json
from flask import Flask, request, jsonify
from PIL import Image
import numpy as np
import cv2
import pytesseract
from sklearn.linear_model import LinearRegression

app = Flask(__name__)

def image_to_np(img_bytes):
    image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    return np.array(image)

def try_read_axis_prices(img):
    """Try to read y-axis numeric labels using OCR. Returns (top_price, bottom_price) or None."""
    try:
        h,w = img.shape[:2]
        # Crop left area where axis labels typically are
        crop = img[int(h*0.02):int(h*0.98), 0:int(w*0.12)]
        gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
        # Increase contrast
        gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
        _,th = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
        text = pytesseract.image_to_string(th, config='--psm 6 digits')
        # find numbers in text
        import re
        nums = re.findall(r"[-+]?\d*\,?\d+\.\d+|[-+]?\d+\,?\d+|[-+]?\d+", text.replace(' ', '').replace('O','0'))
        if len(nums) >= 2:
            # pick top-most and bottom-most by their vertical position in crop using pytesseract boxes
            boxes = pytesseract.image_to_data(th, output_type=pytesseract.Output.DICT)
            paired = []
            for i,txt in enumerate(boxes['text']):
                t = txt.strip().replace(',','.')
                if t.replace('.','').replace('-','').isdigit():
                    try:
                        val = float(t)
                        top = boxes['top'][i]
                        paired.append((top,val))
                    except:
                        pass
            if len(paired) >= 2:
                paired.sort(key=lambda x: x[0])  # top to bottom
                top_price = paired[0][1]
                bottom_price = paired[-1][1]
                # if values inverted, swap
                if top_price < bottom_price:
                    top_price, bottom_price = bottom_price, top_price
                return float(top_price), float(bottom_price)
            else:
                # fallback to first and last nums
                top_price = float(nums[0].replace(',','.'))
                bottom_price = float(nums[-1].replace(',','.'))
                if top_price < bottom_price:
                    top_price, bottom_price = bottom_price, top_price
                return top_price, bottom_price
    except Exception as e:
        # OCR failed
        return None
    return None

def extract_candles(img):
    """Best-effort extraction of candle tops/bottoms from an image.
       Returns list of (x, open, close, high, low) normalized to [0,1] y-space (0 top, 1 bottom).
    """
    h,w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    # edge detect vertical lines (wicks) and filled rectangles (bodies) heuristically
    edges = cv2.Canny(gray, 50, 150)
    # morphological to group vertical structures
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,9))
    vert = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
    # Sum columns to find candle x positions
    col_sum = vert.sum(axis=0)
    # find peaks in col_sum
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(col_sum, height=np.max(col_sum)*0.2, distance=6)
    candles = []
    for px in peaks:
        # look vertically at this x
        col = gray[:, max(0,px-3):min(w,px+3)]
        # find dark regions (wicks/bodies)
        thresh = cv2.threshold(col, 200, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
        ys = np.where(thresh.sum(axis=1) > 0)[0]
        if len(ys) < 3:
            continue
        top = ys[0] / h
        bottom = ys[-1] / h
        # Estimate body by color: sample small horizontal band
        band = img[int(h*top):int(h*bottom), max(0,px-6):min(w,px+6)]
        # compute average green/red ratio to decide bullish/bearish body if colored
        avg = band.mean(axis=(0,1)) if band.size>0 else np.array([0,0,0])
        # approximate open/close: assume body occupies middle half of wick
        body_top = top + (bottom-top)*0.25
        body_bottom = top + (bottom-top)*0.75
        open_p = body_top
        close_p = body_bottom
        # determine direction by average green vs red (heuristic)
        direction = 'unknown'
        if avg[1] > avg[2]*1.03 and avg[1] > avg[0]*1.03:
            direction = 'bull'
        elif avg[2] > avg[1]*1.03 and avg[2] > avg[0]*1.03:
            direction = 'bear'
        # normalize: y=0 top
        candles.append((px/w, open_p, close_p, top, bottom, direction))
    # sort by x
    candles.sort(key=lambda x: x[0])
    return candles

def candles_to_price_series(candles, top_price=None, bottom_price=None):
    """Convert normalized candle ys to price series using y->price mapping.
       If no mapping, return relative prices [0..1].
    """
    prices = []
    if len(candles)==0:
        return prices
    for c in candles:
        _, open_p, close_p, high_p, low_p, dirc = c
        # use close midpoint
        close = (open_p + close_p)/2.0
        # y->price: 0->top_price, 1->bottom_price
        if top_price is not None and bottom_price is not None:
            pr = top_price + (bottom_price - top_price) * close
        else:
            pr = 1.0 - close  # normalized so higher on image = larger price
        prices.append(pr)
    return prices

def analyze_prices(prices):
    """Given a list of prices (oldest->newest), compute signals and probabilities.
    """
    res = {}
    n = len(prices)
    if n < 3:
        return {
            "recommendation":"HOLD",
            "probability":35.0,
            "confidence":0.25,
            "notes":"Too few candles detected for reliable signal."
        }
    arr = np.array(prices).reshape(-1,1)
    # trend by linear regression
    X = np.arange(len(prices)).reshape(-1,1)
    lr = LinearRegression().fit(X, arr)
    slope = float(lr.coef_[0][0])
    # moving averages
    short_n = min(3, n-1)
    long_n = min(8, n-1)
    short_ma = float(np.mean(prices[-short_n:]))
    long_ma = float(np.mean(prices[-long_n:]))
    # percent change last candle
    pct = (prices[-1] - prices[-2]) / abs(prices[-2]) if prices[-2] !=0 else 0.0
    pct *= 100.0
    score = 0.0
    notes = []
    # trend contribution
    if slope > 0:
        score += 0.4
        notes.append("Upward short-term slope")
    else:
        score -= 0.4
        notes.append("Downward short-term slope")
    # MA crossover
    if short_ma > long_ma:
        score += 0.5
        notes.append("Short MA above Long MA (bullish)")
    else:
        score -= 0.5
        notes.append("Short MA below Long MA (bearish)")
    # last candle momentum
    if pct > 0.15:
        score += 0.3
        notes.append(f"Recent positive momentum ({pct:.2f}%)")
    elif pct < -0.15:
        score -= 0.3
        notes.append(f"Recent negative momentum ({pct:.2f}%)")
    # normalize score to probability [0..100]
    prob = 50 + score*50  # baseline 50%
    prob = max(5.0, min(95.0, prob))
    # confidence based on number of candles and slope magnitude and MA separation
    conf = min(0.99, 0.2 + min(1.0, n/30.0) + min(0.5, abs(slope)*5.0))
    conf = float(conf)
    # recommendation
    recommendation = "HOLD"
    if prob >= 60:
        recommendation = "BUY" if score>0 else "SELL"
    elif prob <= 40:
        recommendation = "SELL" if score<0 else "BUY"
    return {
        "recommendation": recommendation,
        "probability": round(prob,2),
        "confidence": round(conf,3),
        "notes": "; ".join(notes),
        "short_ma": short_ma,
        "long_ma": long_ma,
        "slope": slope,
        "last_pct": pct
    }

@app.route("/predict", methods=["POST"])
def predict():
    # Accept image file form-data under 'chart' key
    if 'chart' not in request.files:
        return jsonify({"error":"Please send image file under form field 'chart'"}), 400
    file = request.files['chart']
    img_bytes = file.read()
    img = image_to_np(img_bytes)
    # try read axis
    axis = try_read_axis_prices(img)
    if axis is not None:
        top_price, bottom_price = axis
    else:
        top_price, bottom_price = None, None
    candles = extract_candles(img)
    prices = candles_to_price_series(candles, top_price, bottom_price)
    analysis = analyze_prices(prices)
    # exact timestamp (server time in ISO with milliseconds)
    now = datetime.datetime.utcnow().isoformat() + "Z"
    response = {
        "timestamp_utc": now,
        "timezone": "UTC",
        "input_candles_detected": len(candles),
        "analysis": analysis
    }
    return jsonify(response)

@app.route("/ping", methods=["GET"])
def ping():
    return jsonify({"status":"ok","server_time_utc": datetime.datetime.utcnow().isoformat() + "Z"})

if __name__ == "__main__":
    # For local debug only. Render will use gunicorn.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
