
# Trader Indicator - Image-based Chart Analyzer (No requirements.txt)

## 🚀 Descrição
Este projeto é um **indicador trader** que analisa **imagens reais de gráficos** (candlesticks) e retorna uma análise de **compra**, **venda** ou **neutra (HOLD)**, com:
- Probabilidade (%)  
- Nível de confiança  
- Horário exato UTC  
- Detecção automática de candles e leitura do eixo Y (via OCR)

O projeto foi preparado para o **Render.com**, usando **Dockerfile**, então **não precisa de requirements.txt**.

---

## 🧩 Deploy no Render

1. Faça upload de todos os arquivos (`app.py`, `Dockerfile`, `Procfile`, `README.md`) para um repositório GitHub.  
2. No Render, crie um novo **Web Service** e conecte o repositório.
3. Render detectará o `Dockerfile` e fará o deploy automaticamente.

---

## 🧠 Endpoint principal

**POST /predict**  
Envie a imagem do gráfico via `multipart/form-data` com o campo `chart`:

```bash
curl -X POST -F "chart=@grafico.png" https://seuapp.onrender.com/predict
```

**Resposta exemplo:**
```json
{
  "timestamp_utc": "2025-11-09T22:00:00.123Z",
  "timezone": "UTC",
  "input_candles_detected": 12,
  "analysis": {
    "recommendation": "BUY",
    "probability": 72.5,
    "confidence": 0.68,
    "notes": "Upward short-term slope; Short MA above Long MA (bullish); Recent positive momentum (0.45%)"
  }
}
```

---

## ⚙️ Build e Start Command (Render.com)
> (Já incluído no Dockerfile, mas caso precise definir manualmente)

- **Build Command:** *(deixe em branco — Render usa o Dockerfile)*  
- **Start Command:** `gunicorn app:app --workers 2 --threads 4 --timeout 120`

---

## ⚠️ Aviso
Este projeto é educativo e **não constitui recomendação financeira**.
Use por sua conta e risco.
