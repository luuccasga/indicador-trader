# Indicador Trader IA 📊

Este projeto analisa imagens de gráficos e retorna sinais de **compra (CALL)** ou **venda (PUT)** com base em padrões visuais.

## Endpoints

- `/` → Página inicial
- `/analisar` → Envie uma imagem via `POST` para obter análise

### Exemplo de uso (via cURL)
```bash
curl -X POST -F "imagem=@grafico.jpeg" https://seuapp.onrender.com/analisar
```